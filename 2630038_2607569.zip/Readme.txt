encode-sudoku's.py:
The given input files are decoded and stored in a folder as textfiles for each line. Code based on Rick van Ravensberg.

SAT-to-csv.py:
Takes a folder of DIMACS .txt files (current: sudokus/*.txt), iterates over the files, preforms basic-DP, DLIS and 2-sided Jeroslow-wang
and stores it in output.csv

Statistics.ipynb:
Jupiter Notebook for the statistical tests